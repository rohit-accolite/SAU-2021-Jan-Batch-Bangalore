create
    definer = root@localhost procedure maxScore(IN team varchar(32), OUT result int)
begin
	select max(Team_score) into result from teams where Team_name = team;
end;

